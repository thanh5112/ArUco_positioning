from pymavlink import mavutil
import time
import threading


class DroneMovement:
    def __init__(self, connection_string="tcp:127.0.0.1:5762"): #/dev/ttyUSB0 #udp:192.168.4.2:14550 #tcp:127.0.0.1:5762
        """ Initialize connection to the drone """
        self.lock = threading.Lock()
        try:
            self.master = mavutil.mavlink_connection(connection_string)
            self.master.wait_heartbeat()
            print("[✅] Vehicle Connected!")
            self.connected = True
        except Exception as e:
            print(f"[❌] Failed to connect to drone: {e}")
            self.connected = False

    def connect(self):
        return self.connected

    def arm(self):
        """ Arms the drone and waits for acknowledgment """
        if not self.connected:
            return False
        self.master.arducopter_arm()
        print("[✅] Drone Arming...")
        self._wait_for_ack(mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM)
        self._print_telemetry()
        return True

    def disarm(self):
        """ Disarms the drone and waits for acknowledgment """
        if not self.connected:
            return False
        self.master.arducopter_disarm()
        print("[✅] Drone Disarming...")
        self._wait_for_ack(mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM)
        self._print_telemetry()
        return True

    def takeoff(self, altitude):
        """ Takeoff to a given altitude """
        if not self.connected:
            return False
        print(f"[🚀] Taking off to {altitude}m...")
        self.master.mav.command_long_send(
            self.master.target_system,
            self.master.target_component,
            mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
            0, 0, 0, 0, 0, 0, 0, altitude
        )
        self._wait_for_ack(mavutil.mavlink.MAV_CMD_NAV_TAKEOFF)
        time.sleep(10)
        self._print_telemetry()
        return True

    def land(self):
        """ Land the drone """
        if not self.connected:
            return False
        print("[🛬] Landing...")
        self.master.mav.command_long_send(
            self.master.target_system,
            self.master.target_component,
            mavutil.mavlink.MAV_CMD_NAV_LAND,
            0, 0, 0, 0, 0, 0, 0, 0
        )
        self._wait_for_ack(mavutil.mavlink.MAV_CMD_NAV_LAND)
        self._print_telemetry()
        return True

    def move(self, direction):
        """ Move in a given direction """
        if not self.connected:
            return False

        movement_commands = {
            "forward": (500, 0, 500, 0),
            "backward": (-500, 0, 500, 0),
            "left": (0, -500, 500, 0),
            "right": (0, 500, 500, 0),
            "up": (0, 0, 1000, 0),
            "down": (0, 0, 300, 0)
        }

        if direction in movement_commands:
            x, y, z, r = movement_commands[direction]
            self.master.mav.manual_control_send(
                self.master.target_system, x, y, z, r, 0
            )
            print(f"[➡️] Moving {direction}")
            self._print_telemetry()
            return True
        print("[❌] Invalid Movement Command")
        return False

    def set_mode(self, mode):
        try:
            with self.lock:  # Ensure thread-safe access
                if not self.connected:
                    print("[❌] Drone is not connected!")
                    return False

                mode_mapping = {
                    "Stabilize": "STABILIZE",
                    "Guided": "GUIDED",
                    "Auto": "AUTO",
                    "Loiter": "LOITER",
                    "RTL": "RTL",
                    "Land": "LAND"
                }

                if mode not in mode_mapping:
                    print(f"[❌] Invalid Mode: {mode}")
                    return False

                mode_id = self.master.mode_mapping()[mode_mapping[mode]]
                self.master.mav.set_mode_send(
                    self.master.target_system,
                    mavutil.mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
                    mode_id
                )

                print(f"[🔄] Changing Mode to {mode}...")
                time.sleep(2)  # Wait for mode change
                self._print_telemetry()
                return True
        except Exception as e:
            print(f"[❌] Failed to set mode: {e}")
            return False

    def emergency_stop(self):
        """ Immediately stops all movement """
        if self.connected:
            self.master.mav.manual_control_send(
                self.master.target_system, 0, 0, 500, 0, 0
            )
            print("[🛑] Emergency Stop Activated!")
            self._print_telemetry()

    def _wait_for_ack(self, command_id, timeout=5):
        """ Wait for command acknowledgment from Pixhawk """
        start_time = time.time()
        while time.time() - start_time < timeout:
            msg = self.master.recv_match(type="COMMAND_ACK", blocking=True, timeout=1)
            if msg and msg.command == command_id:
                if msg.result == mavutil.mavlink.MAV_RESULT_ACCEPTED:
                    print("[✅] Command Acknowledged!")
                    return True
                else:
                    print("[❌] Command Rejected!")
                    return False
        print("[⚠️] No Acknowledgment Received!")
        return False

    def _print_telemetry(self):
        """ Print telemetry data (altitude, GPS, battery) """
        try:
            msg = self.master.recv_match(type=["GLOBAL_POSITION_INT", "BATTERY_STATUS"], blocking=True, timeout=1)
            if msg:
                if msg.get_type() == "GLOBAL_POSITION_INT":
                    altitude = msg.relative_alt / 1000.0  # Convert mm to meters
                    lat = msg.lat / 1e7
                    lon = msg.lon / 1e7
                    print(f"🌍 GPS: Lat {lat}, Lon {lon}, Alt {altitude}m")
                elif msg.get_type() == "BATTERY_STATUS":
                    voltage = msg.voltages[0] / 1000.0  # Convert mV to V
                    print(f"🔋 Battery: {voltage}V")
        except Exception as e:
            print(f"[⚠️] Telemetry Data Unavailable: {e}")
