import tkinter as tk
from tkinter import messagebox
from movement import DroneMovement
from aruco import ArucoDetector
import host  # Camera connection module
import threading
import time

class DroneGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Control GUI")

        self.drone = None  # DroneMovement will be initialized only when needed
        self.aruco_detector = ArucoDetector()
        self.camera_connected = False
        self.drone_connected = False

        # Connection button
        tk.Button(root, text="Connect to Pixhawk", command=self.connect_drone).grid(row=0, column=0, padx=10, pady=10)
        tk.Button(root, text="Connect to Camera", command=self.connect_camera).grid(row=0, column=1, padx=10, pady=10)
        tk.Button(root, text="Start ArUco Detection", command=self.aruco_control).grid(row=0, column=2, padx=10, pady=10)

        # Drone control buttons (Initially disabled)
        self.arm_button = tk.Button(root, text="Arm", command=self.arm_drone, state=tk.DISABLED)
        self.arm_button.grid(row=1, column=0, padx=10, pady=10)
        self.disarm_button = tk.Button(root, text="Disarm", command=self.disarm_drone, state=tk.DISABLED)
        self.disarm_button.grid(row=1, column=1, padx=10, pady=10)

        self.takeoff_button = tk.Button(root, text="Takeoff", command=self.takeoff, state=tk.DISABLED)
        self.takeoff_button.grid(row=2, column=0, padx=10, pady=10)
        self.land_button = tk.Button(root, text="Land", command=self.land, state=tk.DISABLED)
        self.land_button.grid(row=2, column=1, padx=10, pady=10)

        self.forward_button = tk.Button(root, text="Forward", command=lambda: self.move("forward"), state=tk.DISABLED)
        self.forward_button.grid(row=3, column=1, padx=10, pady=5)
        self.backward_button = tk.Button(root, text="Backward", command=lambda: self.move("backward"), state=tk.DISABLED)
        self.backward_button.grid(row=5, column=1, padx=10, pady=5)
        self.left_button = tk.Button(root, text="Left", command=lambda: self.move("left"), state=tk.DISABLED)
        self.left_button.grid(row=4, column=0, padx=10, pady=5)
        self.right_button = tk.Button(root, text="Right", command=lambda: self.move("right"), state=tk.DISABLED)
        self.right_button.grid(row=4, column=2, padx=10, pady=5)
        self.up_button = tk.Button(root, text="Up", command=lambda: self.move("up"), state=tk.DISABLED)
        self.up_button.grid(row=3, column=2, padx=10, pady=5)
        self.down_button = tk.Button(root, text="Down", command=lambda: self.move("down"), state=tk.DISABLED)
        self.down_button.grid(row=5, column=2, padx=10, pady=5)

        # Flight mode selection
        self.mode_var = tk.StringVar(root)
        self.mode_var.set("Stabilize")
        tk.OptionMenu(root, self.mode_var, "Stabilize", "Guided", "Auto", "Loiter", "RTL", "Land").grid(row=6, column=0, columnspan=2, padx=10, pady=10)
        self.set_mode_button = tk.Button(root, text="Set Mode", command=self.set_mode, state=tk.DISABLED)
        self.set_mode_button.grid(row=6, column=2, padx=10, pady=10)

    def connect_drone(self):
        """ Connect to Pixhawk only when the button is pressed """
        if self.drone_connected:
            messagebox.showinfo("Info", "Drone is already connected!")
            return

        try:
            self.drone = DroneMovement()
            if self.drone.connect():
                self.drone_connected = True
                messagebox.showinfo("Info", "Drone Connected!")
                
                # Enable all drone control buttons
                for button in [
                    self.arm_button, self.disarm_button, self.takeoff_button,
                    self.land_button, self.forward_button, self.backward_button,
                    self.left_button, self.right_button, self.up_button,
                    self.down_button, self.set_mode_button
                ]:
                    button.config(state=tk.NORMAL)
            else:
                messagebox.showerror("Error", "Failed to connect to Drone!")
        except Exception as e:
            messagebox.showerror("Error", f"Connection failed: {e}")

    def connect_camera(self):
        """ Start camera connection only when the button is pressed """
        if self.camera_connected:
            messagebox.showinfo("Info", "Camera is already connected!")
            return

        def start_camera():
            host.establish_connection()
            threading.Thread(target=host.receive_video, daemon=True).start()
            self.camera_connected = True
            messagebox.showinfo("Info", "Camera Connected!")

        threading.Thread(target=start_camera, daemon=True).start()

    def aruco_control(self):
        if not self.camera_connected:
            messagebox.showwarning("Warning", "Please connect the camera first!")
            return

        def detect_aruco():
            while True:
                print("[DEBUG] Running ArUco Detection Loop...")
                self.landing_initiated = False
                marker_id, distance, position, frame = self.aruco_detector.run()
                print(f"[DEBUG] Returned from detector: {marker_id=}, {position=}, {distance=}")

                if marker_id == 0 and not self.landing_initiated:
                    self.landing_initiated = True  # Prevent retriggering
                    print("[🛬] ArUco ID 0 detected! Initiating landing sequence once...")
                    self.set_mode_to_land()
                    self.land()  # Delay slightly to ensure mode set
                    break
                else:
                    print(f"[DEBUG] Marker ID {marker_id} is not 0. Waiting...")
            time.sleep(0.1)
        threading.Thread(target=detect_aruco, daemon=True).start()

        
    def set_mode_to_land(self):
        """Set the flight mode to 'Land'."""
        print("[DEBUG] Attempting to set mode to 'Land'...")
        if self.drone.set_mode("Land"):
            print("[DEBUG] Mode successfully set to 'Land'")
            messagebox.showinfo("Info", "Flight mode set to Land")
        else:
            print("[DEBUG] Failed to set mode to 'Land'")
            messagebox.showerror("Error", "Failed to set mode to Land")

    def arm_drone(self):
        if self.drone.arm():
            messagebox.showinfo("Info", "Drone Armed!")
        else:
            messagebox.showerror("Error", "Failed to Arm!")

    def disarm_drone(self):
        if self.drone.disarm():
            messagebox.showinfo("Info", "Drone Disarmed!")
        else:
            messagebox.showerror("Error", "Failed to Disarm!")

    def takeoff(self):
        if self.drone.takeoff(5):
            messagebox.showinfo("Info", "Drone Taking Off!")
        else:
            messagebox.showerror("Error", "Takeoff Failed!")

    def land(self):
        if self.drone.land():
            messagebox.showinfo("Info", "Drone Landing!")
        else:
            messagebox.showerror("Error", "Landing Failed!")

    def move(self, direction):
        if self.drone.move(direction):
            messagebox.showinfo("Info", f"Moving {direction}")
        else:
            messagebox.showerror("Error", f"Failed to Move {direction}")

    def set_mode(self):
        mode = self.mode_var.get()
        if self.drone.set_mode(mode):
            messagebox.showinfo("Info", f"Mode set to {mode}")
        else:
            messagebox.showerror("Error", f"Failed to set mode {mode}")

if __name__ == "__main__":
    root = tk.Tk()
    gui = DroneGUI(root)
    root.mainloop()
