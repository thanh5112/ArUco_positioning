import cv2
import numpy as np
import threading
import host  # Import the camera module

class ArucoDetector:
    def __init__(self):
        """Initialize the ArUco detector."""
        self.aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_6X6_250)
        self.aruco_params = cv2.aruco.DetectorParameters()
        self.running = False  # Flag to control detection loop

    def detect_markers(self, frame):
        """Detect ArUco markers in the given frame."""
        detector = cv2.aruco.ArucoDetector(self.aruco_dict, self.aruco_params)
        bboxs, ids, _ = detector.detectMarkers(frame)

        if ids is not None:
            for i in range(len(ids)):
                center = tuple(map(int, np.mean(bboxs[i][0], axis=0)))
                distance = np.linalg.norm(np.array([frame.shape[1]//2, frame.shape[0]//2]) - np.array(center))
                position = (frame.shape[1]//2 - center[0], frame.shape[0]//2 - center[1])

                print(f"✅ Marker ID: {ids[i][0]}, Position: {position}, Distance: {distance:.2f}")

                # Draw marker boundaries and center point
                cv2.drawContours(frame, [bboxs[i][0].astype(int)], -1, (0, 255, 0), 2)
                cv2.circle(frame, center, 5, (0, 0, 255), -1)
                cv2.putText(frame, f"ID: {ids[i][0]}", (center[0] - 20, center[1] - 10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

                # Call PositionAdjustment to adjust the drone's position
                frame = self.PositionAdjustment(frame, distance, position)
                marker_id = int(ids[i][0])
                return marker_id, distance, position, frame

        return None, None, None, frame  # No marker detected

    def display(self, frame):
        """Display the center lines and a red dot on the frame."""
        center = (frame.shape[1] // 2, frame.shape[0] // 2)  # Center of the frame
        radius = 5  # Radius of the dot
        color = (0, 0, 255)  # Red color in BGR
        thickness = -1  # Filled circle

        height, width = frame.shape[:2]

        # Define points for the vertical line (middle of the width)
        vertical_start = (width // 2, 0)  # Top middle
        vertical_end = (width // 2, height)  # Bottom middle

        # Define points for the horizontal line (middle of the height)
        horizontal_start = (0, height // 2)  # Left middle
        horizontal_end = (width, height // 2)  # Right middle

        # Draw the vertical center line
        cv2.line(frame, vertical_start, vertical_end, (0, 255, 0), 1)  # Green color, thickness 1

        # Draw the horizontal center line
        cv2.line(frame, horizontal_start, horizontal_end, (0, 255, 0), 1)  # Green color, thickness 1

        # Display the frame center with a red dot
        cv2.circle(frame, center, radius, color, thickness)

    def PositionAdjustment(self, frame, distance, position):
        """Autonomous control for adjusting the drone's position based on marker distance and position."""
        if distance is None or position is None:
            return frame
        x, y = position
        if distance > 10:
            if x > 0 and y > 0:
                cv2.putText(frame, "Y-Move Down", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(frame, "X-More to left", (10, frame.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            elif x > 0 and y < 0:
                cv2.putText(frame, "Y-Move Up", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(frame, "X-More to left", (10, frame.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            elif x < 0 and y < 0:
                cv2.putText(frame, "Y-Move Up", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(frame, "X-More to Right", (10, frame.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            elif x < 0 and y > 0:
                cv2.putText(frame, "Y-Move Down", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                cv2.putText(frame, "X-More to Right", (10, frame.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        else: 
            cv2.putText(frame, "Y-Aligned Frame", (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, "X-Aligned Frame", (10, frame.shape[0] - 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        return frame

    def GetdistanceFromCamera(self, frame, bboxtl, bboxbr):
        """Calculate the area of the bounding box relative to the frame and display the percentage."""
        height, width = frame.shape[:2]
        FrameArea = height * width

        BoxArea = (bboxbr[0] - bboxtl[0]) * (bboxbr[1] - bboxtl[1])  # Area of the bounding box

        Contribution = (BoxArea / FrameArea) * 100  # Calculate the contribution percentage
        return cv2.putText(frame, f"Area by Frame: {Contribution:.2f} %", 
                           (10, frame.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, 
                           (255, 255, 0), 2)

    def run(self):
        """Continuously process frames for ArUco detection."""
        self.running = True
        while self.running:
            with host.frame_lock:  # Ensure thread safety
                frame = host.latest_frame.copy() if host.latest_frame is not None else None

            if frame is None:
                print("🔍 No video frame available yet...")
                continue  # Skip this iteration if no frame is available

            marker_id, distance, position, frame = self.detect_markers(frame)

            # Call display function to add center lines and red dot
            self.display(frame)

            if marker_id is not None:
                print(f"🎯 Marker {marker_id} detected at {position}, Distance: {distance:.2f}")
                return marker_id, distance, position, frame

            cv2.imshow("Aruco Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cv2.destroyAllWindows()
        self.running = False

    def stop(self):
        """Stop the ArUco detection loop."""
        self.running = False
