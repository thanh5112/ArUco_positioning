import cv2
import socket
import base64
import numpy as np
import time
import threading

BUFF_SIZE = 65536
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFF_SIZE * 8)  # Increase buffer size

server_ip = '192.168.0.118'  # Replace with Raspberry Pi's IP
server_port = 8888

latest_frame = None  # Stores the latest frame
frame_lock = threading.Lock()  # Thread lock to prevent race conditions
camera_running = False  # Prevents multiple connections

def establish_connection():
    """ Attempt to establish a connection with the Raspberry Pi """
    global camera_running
    if camera_running:
        print("Camera is already connected!")
        return

    while True:
        try:
            print(f"Trying to connect to {server_ip}:{server_port} ...")
            client_socket.sendto(b'Hello', (server_ip, server_port))  # Send handshake
            client_socket.settimeout(5)  # Timeout for response
            packet, _ = client_socket.recvfrom(BUFF_SIZE)
            if packet:
                print("Connected successfully!")
                client_socket.settimeout(None)  # Remove timeout after successful connection
                camera_running = True
                return
        except socket.timeout:
            print("Connection timeout. Retrying...")
        except Exception as e:
            print(f"Error: {e}")
        time.sleep(2)  # Wait before retrying

def receive_video():
    """ Thread for receiving video frames """
    global latest_frame, camera_running
    if not camera_running:
        print("Camera is not connected! Start `establish_connection()` first.")
        return

    while True:
        try:
            packet, _ = client_socket.recvfrom(BUFF_SIZE)
            frame_data = base64.b64decode(packet)
            np_frame = np.frombuffer(frame_data, dtype=np.uint8)
            frame = cv2.imdecode(np_frame, cv2.IMREAD_COLOR)

            if frame is not None:
                with frame_lock:
                    latest_frame = frame.copy()  # Ensure thread safety

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        except Exception as e:
            print(f"Error receiving video: {e}")
            print("Reconnecting...")
            establish_connection()

    client_socket.close()
    cv2.destroyAllWindows()
